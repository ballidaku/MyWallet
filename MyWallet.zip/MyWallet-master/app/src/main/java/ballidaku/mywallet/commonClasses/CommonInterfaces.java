package ballidaku.mywallet.commonClasses;

/**
 * Created by sharanpalsingh on 22/12/17.
 */

public interface CommonInterfaces
{
    public interface deleteDetail
    {
        void onDelete();
    }
}
