package ballidaku.mywallet.roomDatabase;

import android.content.Context;
import android.os.AsyncTask;

import ballidaku.mywallet.roomDatabase.dataModel.AccountDetailsDataModel;

public class ExecuteQueryAsyncTask<T> extends AsyncTask<Void, Void, T>
{
    Context context;
    T data;
    int a=0;
    public ExecuteQueryAsyncTask(Context context,T data)
    {
        this.context=context;
        this.data=data;
        execute();
    }

    @Override
    protected  T doInBackground(Void... params)
    {
        if(a==1)
        {
            return (T)MyRoomDatabase.getInstance(context).accountDetailsDataModelDao().insert((AccountDetailsDataModel) data);
        }
        else
        {
            return (T)MyRoomDatabase.getInstance(context).accountDetailsDataModelDao().getAllData();
        }
        return null;
    }

    @Override
    protected void onPostExecute(T aVoid)
    {

    }
}