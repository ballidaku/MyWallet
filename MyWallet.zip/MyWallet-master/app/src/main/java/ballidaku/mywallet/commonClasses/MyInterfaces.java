package ballidaku.mywallet.commonClasses;

/**
 * Created by sharanpalsingh on 28/12/17.
 */

public interface MyInterfaces
{
    interface UpdateDetails
    {
        void onSuccess();
    }



}
