package ballidaku.mywallet.commonClasses;

/**
 * Created by sharanpalsingh on 26/03/17.
 */
public class MyConstant {


    public static final String SPACE=" : ";


    /*Room database TABLES*/
    public static final String ACCOUNT_DETAILS="account_details";



    public static final String DATABASE_NAME="MyWalletDatabase.db";



    public static final String USER_NAME="user_name";
    public static final String USER_EMAIL="user_email";
    public static final String USER_PHONE="user_phone";

    public static final String USER_ID="user_id";
    public static final String FCM_TOKEN="fcm_token";
    public static final String USERS="users";
    public static final String BANK_DETAILS="bank_details";
    public static final String DETAILS="details";
    public static final String PASSWORD="password";

    public static final String LIST_ITEM_DATA="list_item_data";


    public static final String BANK_NAME="bank_name";
    public static final String ACCOUNT_HOLDER_NAME="account_holder_name";
    public static final String ACCOUNT_NUMBER="account_number";
    public static final String IFSC="ifsc";
    public static final String ATM_NUMBER="atm_number";
    public static final String CVV="cvv";
    public static final String VALID_FROM="valid_from";
    public static final String VALID_THRU="valid_thru";
    public static final String NET_BANKING_ID="net_banking_id";

    public static final String FROM_WHERE="from_where";
    public static final String NEW="new";
    public static final String EDIT="edit";

    public static final String TITLE="title";
    public static final String VALUE="value";
    public static final String TYPE="type";
    public static final String ADDITIONAL_DATA="additional_data";
    public static final String SECRET="Secret";
    public static final String TEXT="Text";
    public static final String VISIBLE="visible";
    public static final String INVISIBLE="invisible";


    public static final String MPIN="mpin";
    public static final String EMPTY="empty";
    public static final String CHECK_MPIN="check_mpin";

    public static final String FIRST_TIME="first_time";
    public static final String CONFIRM_FIRST_TIME="confirm_first_time";
    public static final String CHANGE_MPIN="change_mpin";
    public static final String NEW_PIN_AFTER_CHANGE="new_pin_after_change";
    public static final String CONFIRM_PIN_AFTER_CHANGE="confirm_pin_after_change";
}
